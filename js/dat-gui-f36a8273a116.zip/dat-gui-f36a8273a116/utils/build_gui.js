require('./builder.js').build({
   "baseUrl": "../src/",
   "main": "dat/gui/GUI",
   "out": "../build/dat.gui.js",
   "minify": false,
   "shortcut": "dat.GUI",
   "paths": {}
});